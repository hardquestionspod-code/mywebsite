<?php
// Start session
session_start();

// Dummy login for demonstration
$errors = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Replace this with real database check
    if ($username === 'user' && $password === 'pass') {
        $_SESSION['user'] = $username;
        header('Location: dashboard.php'); // redirect after login
        exit;
    } else {
        $errors = 'Invalid username or password.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<style>
body {
  font-family: Arial, sans-serif;
  background: #f4f4f4;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.login-container {
  background: #fff;
  padding: 2rem;
  border-radius: 10px;
  box-shadow: 0 10px 25px rgba(0,0,0,0.2);
  width: 300px;
}

.login-container h2 {
  text-align: center;
  margin-bottom: 1.5rem;
}

.login-container input {
  width: 100%;
  padding: 0.7rem;
  margin-bottom: 1rem;
  border-radius: 5px;
  border: 1px solid #ccc;
}

.login-container button {
  width: 100%;
  padding: 0.7rem;
  background: #f0c040;
  border: none;
  border-radius: 5px;
  font-weight: bold;
  cursor: pointer;
  transition: background 0.3s ease;
}

.login-container button:hover {
  background: #e6b030;
}

.error {
  color: red;
  text-align: center;
  margin-bottom: 1rem;
}
</style>
</head>
<body>

<div class="login-container">
  <h2>Login</h2>
  <?php if ($errors) echo "<div class='error'>$errors</div>"; ?>
  <form action="" method="POST">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
  </form>
</div>

</body>
</html>
